#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void print_hello();
int factorial(int n);

#endif
